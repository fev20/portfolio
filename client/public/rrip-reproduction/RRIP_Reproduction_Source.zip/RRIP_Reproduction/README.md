# 순차 읽기가 캐시를 비울 때

Aamer Jaleel 외, *High Performance Cache Replacement Using Re-Reference Interval Prediction (RRIP)*, ISCA 2010의 그림 3과 식 (1)을 Python으로 재현했다. `RRIP_Reproduction.html`을 열면 접근 순서를 한 단계씩 볼 수 있다. 인터넷 연결 없이 동작한다.

## 결과

| 정책 | 그림 3 전체 적중 | 그림 3 마지막 두 접근 적중 | 화면 버퍼 모형에서 활성 라인 적중 |
|---|---:|---:|---:|
| LRU | 2 / 10 | 0 / 2 | 0 / 64 |
| NRU | 2 / 10 | 0 / 2 | 0 / 64 |
| 2비트 SRRIP-HP | 4 / 10 | 2 / 2 | 64 / 64 |

그림 3에서 세 정책의 캐시 슬롯 120개와 적중·실패 판정 30개를 원문 도식과 대조했다. `a1 a2 a2 a1 b1 b2 b3 b4 a1 a2`를 4슬롯의 빈 캐시에 입력했다. NRU 그림의 동작 설명은 삽입 시 비트가 1이라고 쓰지만, 도식과 §4.1의 삽입 설명은 0이다. 0을 사용했으며 1을 사용하는 변형은 도식과 10단계 모두에서 달랐다.

SRRIP-HP의 스캔 길이 실험에서는 슬롯 수 2·4·8·16개, 각 슬롯 수보다 작은 활성 블록 수, 상태 비트 폭 1–4비트를 조합했다. 활성 블록을 두 번씩 접근한 다음 다른 블록을 순차 접근하고, 재접근 직전 활성 블록이 모두 남았는지 확인했다. 4,667개 SRRIP-HP 사례가 식 (1)에 따른 예측과 일치했다. LRU와 NRU까지 총 5,553개 사례를 실행했다.

화면 버퍼 모형은 원본 Linux DOOM의 320×200 화면을 기준으로 픽셀당 1바이트를 가정했다. 캐시는 32세트, 16슬롯, 라인당 64바이트이며 라인 번호를 32로 나눈 나머지로 세트를 정한다. 세트당 활성 라인 2개를 두 번 읽은 뒤, 겹치지 않는 화면 버퍼의 라인 1,000개를 순차로 읽고 활성 라인 64개를 재접근했다. 카메라에서 실제로 측정한 값이나 논문의 실제 워크로드 성능 그래프는 이 재현의 범위 밖이다.

## 실행

검증 환경은 Python 3.12.14와 Matplotlib 3.10.8이다. Python 3.10 이상이 필요하다.

```sh
python -m pip install -r requirements.txt
python reproduce.py
python build_report.py
```

- `reproduce.py`는 그림 3 대조, 식 (1) 확인, 화면 버퍼 모형을 실행하며 일치 조건이 깨지면 실패한다.
- `results/figure3.csv`는 접근별 캐시 상태, `results/scan_sweep.csv`는 순차 읽기 길이 실험, `results/frame_model.csv`는 화면 버퍼 모형 결과다.
- `results/scan_resistance.png`는 실험에서 그린 그래프다. `results/evidence.json`은 HTML 생성에 쓰인 데이터를 담고 있다.
- `build_report.py`는 수치와 그래프를 넣어 오프라인 HTML을 다시 만든다.

## 출처

- [Jaleel 외, ISCA 2010 원문](https://jaleels.org/ajaleel/publications/isca2010-rrip.pdf) · §4.1, §4.2, 그림 3, 식 (1)
- [id Software, Linux DOOM 1.10 화면 크기 정의](https://github.com/id-Software/DOOM/blob/master/linuxdoom-1.10/doomdef.h)

AI가 논문 선택, 실험 구현, 수치 검증, 시각화와 문서 작성을 수행했다.
