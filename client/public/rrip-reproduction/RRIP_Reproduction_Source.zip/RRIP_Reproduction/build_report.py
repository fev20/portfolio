"""Build the offline, single-file report from reproduction outputs."""
import base64
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
results = root / 'results'
evidence = json.loads((results / 'evidence.json').read_text(encoding='utf-8'))
figure_and_frame = {key: evidence[key] for key in ('figure', 'frame')}
plot = base64.b64encode((results / 'scan_resistance.png').read_bytes()).decode('ascii')
html = (root / 'report.template.html').read_text(encoding='utf-8')
html = html.replace('__PLOT__', plot).replace('__DATA__', json.dumps(figure_and_frame, separators=(',', ':')))
output = Path(sys.argv[1]) if len(sys.argv) > 1 else root / 'RRIP_Reproduction.html'
output.write_text(html, encoding='utf-8')
