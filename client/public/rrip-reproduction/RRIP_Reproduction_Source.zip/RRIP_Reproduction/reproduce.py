"""Reproduce Figure 3 and run controlled extensions of Jaleel et al., ISCA 2010."""

import csv
import json
from pathlib import Path
import sys


class CacheSet:
    def __init__(self, ways, policy, bits=2):
        self.policy = policy
        self.ways = ways
        self.max_age = (1 << bits) - 1
        self.blocks = [None] * ways
        self.ages = [self.max_age] * ways

    def access(self, block):
        hit = block in self.blocks
        if self.policy == 'LRU':
            if hit:
                self.blocks.remove(block)
            else:
                self.blocks.pop()
            self.blocks.insert(0, block)
        elif hit:
            self.ages[self.blocks.index(block)] = 0
        else:
            while self.max_age not in self.ages:
                self.ages = [age + 1 for age in self.ages]
            victim = self.ages.index(self.max_age)
            self.blocks[victim] = block
            # The Figure 3 NRU diagram clears the bit on a fill. The section
            # describes this policy in prose and the figure legend disagrees.
            self.ages[victim] = 0 if self.policy == 'NRU' else self.max_age - 1
        return hit

    def snapshot(self):
        if self.policy == 'LRU':
            return [block or '-' for block in self.blocks]
        return [f'{block or "-"}:{age}' for block, age in zip(self.blocks, self.ages)]


TRACE = 'a1 a2 a2 a1 b1 b2 b3 b4 a1 a2'.split()
# Transcribed separately from the cells of Figure 3. Each line is the state
# after that reference, with LRU arranged from most to least recently used.
EXPECTED = {
    'LRU': '''a1 - - -
a2 a1 - -
a2 a1 - -
a1 a2 - -
b1 a1 a2 -
b2 b1 a1 a2
b3 b2 b1 a1
b4 b3 b2 b1
a1 b4 b3 b2
a2 a1 b4 b3''',
    'NRU': '''a1:0 -:1 -:1 -:1
a1:0 a2:0 -:1 -:1
a1:0 a2:0 -:1 -:1
a1:0 a2:0 -:1 -:1
a1:0 a2:0 b1:0 -:1
a1:0 a2:0 b1:0 b2:0
b3:0 a2:1 b1:1 b2:1
b3:0 b4:0 b1:1 b2:1
b3:0 b4:0 a1:0 b2:1
b3:0 b4:0 a1:0 a2:0''',
    'SRRIP-HP': '''a1:2 -:3 -:3 -:3
a1:2 a2:2 -:3 -:3
a1:2 a2:0 -:3 -:3
a1:0 a2:0 -:3 -:3
a1:0 a2:0 b1:2 -:3
a1:0 a2:0 b1:2 b2:2
a1:1 a2:1 b3:2 b2:3
a1:1 a2:1 b3:2 b4:2
a1:0 a2:1 b3:2 b4:2
a1:0 a2:0 b3:2 b4:2''',
}


def require_equal(actual, expected, description):
    if actual != expected:
        raise AssertionError(f'{description}: expected {expected!r}, got {actual!r}')


def reproduce_figure():
    rows = []
    for policy, states in EXPECTED.items():
        cache = CacheSet(4, policy, bits=1 if policy == 'NRU' else 2)
        expected_hits = 'MMHHMMMMHH' if policy == 'SRRIP-HP' else 'MMHHMMMMMM'
        for step, (block, state, expected_hit) in enumerate(
            zip(TRACE, states.splitlines(), expected_hits, strict=True), start=1
        ):
            hit = cache.access(block)
            require_equal(hit, expected_hit == 'H', (policy, step, 'hit'))
            slots = cache.snapshot()
            require_equal(slots, state.split(), (policy, step, 'state'))
            rows.append(dict(policy=policy, step=step, access=block, hit=hit, state=slots))
    return rows


def sweep_scan_lengths():
    rows = []
    for ways in (2, 4, 8, 16):
        for hot_count in range(1, ways):
            for policy, bits in [('LRU', 0), ('NRU', 1)] + [('SRRIP-HP', bits) for bits in range(1, 5)]:
                bound = ways - hot_count
                if policy == 'SRRIP-HP':
                    bound *= (1 << bits) - 1
                max_scan = max(16, bound + 2)
                for scan_length in range(max_scan + 1):
                    cache = CacheSet(ways, policy, bits=max(bits, 1))
                    hot = [f'a{i}' for i in range(hot_count)]
                    for block in hot * 2:
                        cache.access(block)
                    for index in range(scan_length):
                        cache.access(f'b{index}')
                    retained = sum(block in cache.blocks for block in hot)
                    expected_all = None
                    if policy != 'NRU':
                        limit = ways - hot_count if policy == 'LRU' else ((1 << bits) - 1) * (ways - hot_count)
                        expected_all = scan_length <= limit
                        require_equal(retained == hot_count, expected_all, (policy, ways, hot_count, bits, scan_length))
                    probe_hits = sum(cache.access(block) for block in hot)
                    rows.append(dict(ways=ways, hot_count=hot_count, policy=policy, bits=bits, scan_length=scan_length,
                                     retained=retained, probe_hits=probe_hits, expected_all=expected_all))
    return rows


def frame_model():
    width, height, line_bytes, set_count, ways = 320, 200, 64, 32, 16
    frame_lines = width * height // line_bytes
    hot = [line for index in range(set_count) for line in (index, index + set_count)]
    frame = range(1024, 1024 + frame_lines)
    rows = []
    for policy in EXPECTED:
        sets = [CacheSet(ways, policy, bits=1 if policy == 'NRU' else 2) for _ in range(set_count)]
        for line in hot * 2:
            sets[line % set_count].access(line)
        stream_misses = sum(not sets[line % set_count].access(line) for line in frame)
        retained = sum(line in sets[line % set_count].blocks for line in hot)
        probe_hits = sum(sets[line % set_count].access(line) for line in hot)
        require_equal(stream_misses, frame_lines, (policy, 'frame misses'))
        require_equal(probe_hits, 64 if policy == 'SRRIP-HP' else 0, (policy, 'frame probe'))
        rows.append(dict(policy=policy, stream_misses=stream_misses, retained=retained, probe_hits=probe_hits,
                         hot_lines=len(hot), width=width, height=height, line_bytes=line_bytes,
                         sets=set_count, ways=ways))
    return rows


def compare_nru_legend():
    cache = CacheSet(4, 'SRRIP-HP', bits=1)
    # The legend's insert-with-1 NRU equals one-bit SRRIP-HP with insertion
    # changed to 1. Both use max=1, the same ageing rule and the same tie-break.
    legend_states = []
    for block in TRACE:
        hit = cache.access(block)
        if not hit:
            cache.ages[cache.blocks.index(block)] = 1
        legend_states.append(cache.snapshot())
    figure_states = [line.split() for line in EXPECTED['NRU'].splitlines()]
    differences = [index for index, (actual, expected) in enumerate(
        zip(legend_states, figure_states, strict=True), start=1
    ) if actual != expected]
    require_equal(differences, list(range(1, 11)), 'NRU legend versus printed cells')
    return dict(different_steps=differences, legend_first_fill=legend_states[0], figure_first_fill=figure_states[0])


def make_plot(rows, path):
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from matplotlib.figure import Figure

    figure = Figure(figsize=(9.6, 4.8), facecolor='#ffffff', layout='constrained')
    FigureCanvasAgg(figure)
    ax = figure.subplots()
    for policy, bits, color, style, label in [
        ('SRRIP-HP', 3, '#7c46a1', '-', 'SRRIP-HP (3 bits)'),
        ('SRRIP-HP', 2, '#007a74', '-', 'SRRIP-HP (2 bits)'),
        ('NRU', 1, '#c15f24', '--', 'NRU'),
        ('LRU', 0, '#243b65', ':', 'LRU'),
    ]:
        selected = [row for row in rows if row['ways'] == 4 and row['hot_count'] == 2
                    and row['policy'] == policy and row['bits'] == bits and row['scan_length'] <= 16]
        ax.step([r['scan_length'] for r in selected], [r['retained'] for r in selected],
                where='post', color=color, linestyle=style, linewidth=2.4, label=label)
    ax.set(xlabel='Distinct blocks in scan', ylabel='Hot blocks still in cache', xlim=(0, 16), ylim=(-0.15, 2.2),
           xticks=range(0, 17, 2), yticks=[0, 1, 2], title='Scan resistance in a 4-way cache set')
    ax.grid(axis='y', alpha=0.22)
    ax.spines[['right', 'top']].set_visible(False)
    ax.legend(loc='upper right', bbox_to_anchor=(1, -0.15), ncols=2, frameon=False)
    figure.savefig(path, dpi=180)


def main(output_dir):
    output_dir.mkdir(parents=True, exist_ok=True)
    figure_rows = reproduce_figure()
    sweep_rows = sweep_scan_lengths()
    frame_rows = frame_model()
    for name, rows in [('figure3', figure_rows), ('scan_sweep', sweep_rows), ('frame_model', frame_rows)]:
        with (output_dir / f'{name}.csv').open('w', encoding='utf-8', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
    make_plot(sweep_rows, output_dir / 'scan_resistance.png')
    compared = sum(row['expected_all'] is not None for row in sweep_rows)
    srrip_checks = sum(row['policy'] == 'SRRIP-HP' for row in sweep_rows)
    evidence = dict(figure=figure_rows, sweep=sweep_rows, frame=frame_rows, compared=compared,
                    srrip_checks=srrip_checks, nru_legend=compare_nru_legend())
    (output_dir / 'evidence.json').write_text(json.dumps(evidence, separators=(',', ':')), encoding='utf-8')
    print(f'Figure 3: {len(figure_rows) * 4} cache slots and {len(figure_rows)} hit/miss outcomes match.')
    print(f'Scan sweep: {len(sweep_rows)} cases, {compared} matched predicted retention ({srrip_checks} SRRIP cases).')
    print(f'Frame model: {[(row["policy"], row["probe_hits"]) for row in frame_rows]}')


if __name__ == '__main__':
    main(Path(sys.argv[1] if len(sys.argv) > 1 else 'results'))
